-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 24, 2025 at 05:41 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `solution_explore`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `cid` int(11) NOT NULL,
  `comment` text NOT NULL,
  `lec_id` int(11) NOT NULL,
  `stu_id` int(11) NOT NULL,
  `c_time` time NOT NULL,
  `c_date` date NOT NULL,
  `pid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`cid`, `comment`, `lec_id`, `stu_id`, `c_time`, `c_date`, `pid`) VALUES
(1, 'asdasdasd', 0, 33, '00:20:24', '0000-00-00', 46),
(2, 'testing answer', 0, 33, '00:20:24', '2000-03-19', 46),
(3, 'Second test answer', 0, 33, '00:20:24', '0000-00-00', 46),
(4, 'This is my third comment', 0, 33, '00:20:24', '0000-00-00', 46),
(5, 'Help me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problem', 0, 33, '00:20:24', '0000-00-00', 46),
(6, '- Help me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problem- Help me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problem- Help me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problem', 0, 33, '00:20:24', '0000-00-00', 46),
(7, 'blemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problem- Help me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problem', 0, 33, '00:20:24', '0000-00-00', 46),
(14, 'asdasdasddsas', 0, 33, '00:20:24', '0000-00-00', 46),
(15, 'This is a test ', 0, 33, '00:20:24', '0000-00-00', 46),
(16, 'ning problemHelning problemHelning problemHel', 0, 33, '00:20:24', '0000-00-00', 46),
(17, ' learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to sol', 0, 33, '00:37:31', '2024-02-04', 46),
(18, 'this is first comment from me', 0, 33, '00:38:09', '2024-02-04', 50),
(19, 'Hello this is a new comment from me......................', 0, 30, '00:40:01', '2024-02-04', 50),
(20, 'This is my second problem This is my second problem This is my second problem This is my second problem This is my second problem This is my second problemThis is my second problem This is my second problem This is my second problem This is my second problem This is my second problem This is my second problemThis is my second problem This is my second problem This is my second problem This is my second problem This is my second problem This is my second problemThis is my second problem This is my second problem This is my second problem This is my second problem This is my second problem This is my second problemThis is my second problem This is my second problem This is my second problem This is my second problem This is my second problem This is my second problemThis is my second problem This is my second problem This is my second problem This is my second problem This is my second problem This is my second problem', 0, 30, '00:47:25', '2024-02-04', 50),
(21, 'This is my second problem This is my second problem This is my second problem This is my second problem This is my second problem This is my second problemThis is my second problem This is my second problem This is my second problem This is my second problem This is my second problem This is my second problemThis is my second problem This is my second problem This is my second problem This is my second problem This is my second problem This is my second problemThis is my second problem This is my second problem This is my second problem This is my second problem This is my second problem This is my second problemThis is my second problem This is my second problem This is my second problem This is my second problem This is my second problem This is my second problemThis is my second problem This is my second problem This is my second problem This is my second problem This is my second problem This is my second problemThis is my second problem This is my second problem This is my second problem This is my second problem This is my second problem This is my second problemThis is my second problem This is my second problem This is my second problem This is my second problem This is my second problem This is my second problemThis is my second problem This is my second problem This is my second problem This is my second problem This is my second problem This is my second problemThis is my second problem This is my second problem This is my second problem This is my second problem This is my second problem This is my second problemThis is my second problem This is my second problem This is my second problem This is my second problem This is my second problem This is my second problemThis is my second problem This is my second problem This is my second problem This is my second problem This is my second problem This is my second problem', 0, 30, '00:59:46', '2024-02-04', 50),
(22, 'I will give an answer \n\nhttps://stackoverflow.com/questions/77933414/dockerize-php-application-with-caddy\n\nFROM php:8.2-fpm-alpine\n\nWORKDIR /var/www/html\n\nCOPY . .\n\nRUN curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer\nRUN composer install\n\nEXPOSE 9000\n\nCMD [\"php-fpm\"]', 0, 33, '01:03:40', '2024-02-04', 50),
(23, 'helloo', 0, 33, '01:16:36', '2024-02-04', 51),
(24, 'sdfsdfsdf', 0, 33, '01:33:54', '2024-02-04', 32),
(25, 'this is my fiorts comment', 0, 33, '14:56:59', '2024-02-04', 33),
(26, 'This is my first comment', 0, 32, '15:19:43', '2024-02-04', 53),
(27, 'ok', 0, 33, '17:29:42', '2024-02-04', 53),
(28, 'I know the answer for this question.', 0, 30, '17:33:05', '2024-02-04', 53),
(30, 'gfhbdgfrf', 0, 33, '21:52:58', '2024-02-06', 45),
(31, 'SELECT \n    savedcomment.*, \n    post.*, \n    student.*\nFROM (\n    SELECT \n        MIN(cid) AS min_cid \n    FROM \n        savedcomment \n    WHERE \n        sid = \".$sid.\" \n    GROUP BY \n        pid, sid\n) AS distinct_savedcomment\nINNER JOIN \n    savedcomment ON savedcomment.cid = distinct_savedcomment.min_cid\nINNER JOIN \n    post ON savedcomment.pid = post.pid\nINNER JOIN \n    student ON savedcomment.sid = student.sid\nWHERE \n    savedcomment.sid = \".$sid.\"\nORDER BY \n    savedcomment.cid DESC;', 0, 33, '22:27:24', '2024-02-06', 34),
(32, 'yews', 0, 30, '22:31:19', '2024-02-06', 51),
(34, 'sadasdads', 0, 30, '19:30:24', '2024-02-26', 70),
(35, 'dasdasdasd', 0, 30, '19:55:01', '2024-02-26', 69),
(36, 'test', 0, 35, '21:53:09', '2024-03-05', 76),
(37, 'test', 0, 36, '22:00:09', '2024-03-05', 47),
(38, 'drgdfg', 0, 35, '10:35:07', '2024-03-08', 62),
(39, 'test', 0, 38, '11:25:26', '2024-03-08', 79);

-- --------------------------------------------------------

--
-- Table structure for table `lecturer`
--

CREATE TABLE `lecturer` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `lec_password` varchar(255) NOT NULL,
  `lec_code` varchar(50) NOT NULL,
  `pimg` varchar(255) NOT NULL,
  `course` varchar(255) NOT NULL,
  `added_date` date NOT NULL,
  `updated_date` date NOT NULL,
  `added_time` time NOT NULL,
  `updated_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lecturer`
--

INSERT INTO `lecturer` (`id`, `name`, `lec_password`, `lec_code`, `pimg`, `course`, `added_date`, `updated_date`, `added_time`, `updated_time`) VALUES
(49, 'Upis Eran', '$2y$10$ZC6.ioP0dMBu071ggpMCKufC0l/JTZMHHIsHSDmazs50WYCKOexrK', 'upiser@lecnibm', 'null', 'hr', '2024-01-20', '2024-01-22', '21:50:53', '06:04:00'),
(51, 'Sam Kla', '$2y$10$9H08ikNdF./H.JgHcVldxOsXX8PtN1H.pT1WEZqv5U7IBcYKAVNOe', 'samkl@lecnibm', 'null', 'itcs', '2024-01-22', '2024-01-22', '04:10:29', '06:03:41'),
(52, 'Jhone saman', '$2y$10$xk2nG2.7u2Rv7boDEuQZYuqr8kegyEDHF5ZEc7kp9YrSkcrz9HA/C', 'jhonesa@lecnibm', 'null', 'itcs', '2024-01-22', '2024-01-22', '04:32:27', '06:03:27'),
(53, 'testName Name', '$2y$10$77mWtqaMRBz31NjdD/p62OgdeqQHw7Bt587bfVOxrKwEfqH1CPYjG', 'testnamena@lecnibm', 'null', 'itcs', '2024-01-22', '2024-01-22', '10:54:26', '10:54:26'),
(54, 'ss lastdfdfd', '$2y$10$YtJxbkgy9ovL9LOKYL6lz.Cu1aLldVnIXTcXgKaaXJ.0/6M669NIu', 'ssla@lecnibm', 'null', 'hr', '2024-01-22', '2024-01-22', '11:25:40', '11:25:40'),
(55, 'TestName Jhone', '$2y$10$kJAvfNZbxQb5vKIUa0FXUuRvfKQgxiqiJFWAzwn3n3DFsY6kEelXe', 'testnamejh@lecnibm', 'null', 'hr', '2024-01-22', '2024-01-22', '15:16:59', '15:19:55'),
(56, 'Sugat Manna', '$2y$10$.2Wd1ji5iN/vY9ND5920sOy6y6KOOcMWDny2XUprRaEtAmSRe33BK', 'sugatma@lecnibm', 'null', 'business', '2024-01-25', '2024-02-04', '10:15:55', '18:31:58'),
(58, 'test Lecturer', '$2y$10$oVs7WIlVxGtHQCnWb.DonOnaV3WWgKYrwuWsxkvUAehDT05UDhcW.', 'testle@lecnibm', 'null', 'hr', '2024-03-08', '2024-07-25', '11:12:53', '20:06:36'),
(59, 'Jagath Nimal', '$2y$10$jy2Tr6sAX1BcbrxOJpr2vevrvaE.CNTSZDR6/bDSsG3/QOMpEIbW.', 'jagathni@lecnibm', 'null', 'finance', '2024-07-25', '2024-07-25', '20:17:36', '20:18:24');

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE `log` (
  `logId` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `lid` int(11) NOT NULL,
  `time` time NOT NULL,
  `date` date NOT NULL,
  `name` varchar(225) NOT NULL,
  `course` varchar(225) NOT NULL,
  `username` varchar(225) NOT NULL,
  `status` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `log`
--

INSERT INTO `log` (`logId`, `sid`, `lid`, `time`, `date`, `name`, `course`, `username`, `status`) VALUES
(1, 30, 0, '12:29:07', '2024-01-27', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(2, 30, 0, '12:42:52', '2024-01-27', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(3, 30, 0, '12:54:46', '2024-01-27', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(4, 30, 0, '12:54:49', '2024-01-27', 'Saman', 'itcs', 'kuhdse1020', 'logout'),
(5, 30, 0, '12:57:00', '2024-01-27', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(6, 30, 0, '13:01:28', '2024-01-27', 'Saman', 'itcs', 'kuhdse1020', 'logout'),
(7, 30, 0, '18:24:29', '2024-01-27', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(8, 30, 0, '22:10:38', '2024-01-27', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(9, 30, 0, '22:10:38', '2024-01-27', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(10, 30, 0, '22:10:38', '2024-01-27', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(11, 30, 0, '22:10:39', '2024-01-27', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(12, 30, 0, '22:10:39', '2024-01-27', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(13, 30, 0, '22:10:39', '2024-01-27', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(14, 30, 0, '22:10:39', '2024-01-27', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(15, 30, 0, '22:10:39', '2024-01-27', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(16, 30, 0, '22:10:39', '2024-01-27', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(17, 30, 0, '22:10:39', '2024-01-27', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(18, 30, 0, '22:10:40', '2024-01-27', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(19, 30, 0, '22:11:09', '2024-01-27', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(20, 30, 0, '10:35:24', '2024-01-28', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(21, 30, 0, '10:35:53', '2024-01-28', 'Saman', 'itcs', 'kuhdse1020', 'logout'),
(22, 30, 0, '10:36:26', '2024-01-28', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(23, 30, 0, '10:36:27', '2024-01-28', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(24, 30, 0, '11:04:22', '2024-01-28', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(25, 30, 0, '11:23:44', '2024-01-28', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(26, 30, 0, '11:23:44', '2024-01-28', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(27, 30, 0, '11:23:44', '2024-01-28', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(28, 30, 0, '11:23:44', '2024-01-28', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(29, 30, 0, '11:23:44', '2024-01-28', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(30, 30, 0, '11:23:44', '2024-01-28', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(31, 30, 0, '11:27:27', '2024-01-28', 'Saman', 'itcs', 'kuhdse1020', 'logout'),
(32, 30, 0, '11:27:40', '2024-01-28', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(33, 30, 0, '11:36:18', '2024-01-28', 'Saman', 'itcs', 'kuhdse1020', 'logout'),
(34, 30, 0, '11:36:34', '2024-01-28', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(35, 30, 0, '12:22:25', '2024-01-28', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(36, 30, 0, '14:11:50', '2024-01-28', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(37, 30, 0, '19:44:44', '2024-01-29', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(38, 30, 0, '21:57:21', '2024-01-29', 'Saman', 'itcs', 'kuhdse1020', 'logout'),
(39, 30, 0, '21:57:42', '2024-01-29', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(40, 30, 0, '19:56:54', '2024-01-30', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(41, 30, 0, '21:01:58', '2024-01-30', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(42, 30, 0, '21:01:58', '2024-01-30', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(43, 30, 0, '18:47:07', '2024-01-31', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(44, 31, 0, '19:20:15', '2024-02-02', 'Saman Kumara Nimal', 'hr', 'kuhdhr22.1f-025', 'login'),
(45, 31, 0, '19:45:05', '2024-02-02', 'Saman Kumara Nimal', 'hr', 'kuhdhr22.1f-025', 'logout'),
(46, 30, 0, '19:45:24', '2024-02-02', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(47, 30, 0, '21:09:59', '2024-02-02', 'Saman', 'itcs', 'kuhdse1020', 'logout'),
(48, 31, 0, '21:22:24', '2024-02-02', 'Saman Kumara Nimal', 'hr', 'kuhdhr22.1f-025', 'login'),
(49, 31, 0, '08:19:56', '2024-02-03', 'Saman Kumara Nimal', 'hr', 'kuhdhr22.1f-025', 'login'),
(50, 31, 0, '08:26:56', '2024-02-03', 'Saman Kumara Nimal', 'hr', 'kuhdhr22.1f-025', 'logout'),
(51, 32, 0, '08:36:59', '2024-02-03', 'Nimshi Silva', 'itcs', 'kudcsd22.1f-012', 'login'),
(52, 30, 0, '08:38:23', '2024-02-03', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(53, 30, 0, '10:52:18', '2024-02-03', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(54, 32, 0, '10:59:35', '2024-02-03', 'Nimshi Silva', 'itcs', 'kudcsd22.1f-012', 'login'),
(55, 32, 0, '12:39:07', '2024-02-03', 'Nimshi Silva', 'itcs', 'kudcsd22.1f-012', 'login'),
(56, 32, 0, '12:39:11', '2024-02-03', 'Nimshi Silva', 'itcs', 'kudcsd22.1f-012', 'logout'),
(57, 32, 0, '12:39:21', '2024-02-03', 'Nimshi Silva', 'itcs', 'kudcsd22.1f-012', 'login'),
(58, 30, 0, '12:58:44', '2024-02-03', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(59, 30, 0, '13:03:36', '2024-02-03', 'Saman', 'itcs', 'kuhdse1020', 'logout'),
(60, 32, 0, '13:03:50', '2024-02-03', 'Nimshi Silva', 'itcs', 'kudcsd22.1f-012', 'login'),
(61, 32, 0, '13:05:03', '2024-02-03', 'Nimshi Silva', 'itcs', 'kudcsd22.1f-012', 'logout'),
(62, 31, 0, '13:05:16', '2024-02-03', 'Saman Kumara Nimal', 'hr', 'kuhdhr22.1f-025', 'login'),
(63, 31, 0, '13:06:09', '2024-02-03', 'Saman Kumara Nimal', 'hr', 'kuhdhr22.1f-025', 'logout'),
(64, 32, 0, '13:06:24', '2024-02-03', 'Nimshi Silva', 'itcs', 'kudcsd22.1f-012', 'login'),
(65, 32, 0, '15:40:58', '2024-02-03', 'Nimshi Silva', 'itcs', 'kudcsd22.1f-012', 'logout'),
(66, 32, 0, '15:41:08', '2024-02-03', 'Nimshi Silva', 'itcs', 'kudcsd22.1f-012', 'login'),
(67, 32, 0, '15:41:16', '2024-02-03', 'Nimshi Silva', 'itcs', 'kudcsd22.1f-012', 'logout'),
(68, 30, 0, '15:41:27', '2024-02-03', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(69, 30, 0, '15:42:30', '2024-02-03', 'Saman', 'itcs', 'kuhdse1020', 'logout'),
(70, 30, 0, '19:44:36', '2024-02-03', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(71, 30, 0, '19:55:27', '2024-02-03', 'Saman', 'itcs', 'kuhdse1020', 'logout'),
(72, 33, 0, '19:59:33', '2024-02-03', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'login'),
(73, 33, 0, '00:38:21', '2024-02-04', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'logout'),
(74, 30, 0, '00:38:36', '2024-02-04', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(75, 30, 0, '01:01:31', '2024-02-04', 'Saman', 'itcs', 'kuhdse1020', 'logout'),
(76, 33, 0, '01:01:50', '2024-02-04', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'login'),
(77, 33, 0, '01:37:50', '2024-02-04', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'logout'),
(78, 33, 0, '14:50:59', '2024-02-04', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'login'),
(79, 30, 0, '14:52:52', '2024-02-04', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(80, 33, 0, '14:58:56', '2024-02-04', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'logout'),
(81, 30, 0, '14:59:06', '2024-02-04', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(82, 30, 0, '14:59:35', '2024-02-04', 'Saman', 'itcs', 'kuhdse1020', 'logout'),
(83, 32, 0, '14:59:47', '2024-02-04', 'Nimshi Silva', 'itcs', 'kudcsd22.1f-012', 'login'),
(84, 33, 0, '15:07:59', '2024-02-04', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'login'),
(85, 33, 0, '17:29:59', '2024-02-04', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'logout'),
(86, 30, 0, '17:30:19', '2024-02-04', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(87, 33, 0, '18:48:05', '2024-02-05', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'login'),
(88, 33, 0, '19:55:31', '2024-02-06', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'login'),
(89, 33, 0, '22:28:14', '2024-02-06', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'logout'),
(90, 30, 0, '22:28:33', '2024-02-06', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(91, 30, 0, '22:43:19', '2024-02-06', 'Saman', 'itcs', 'kuhdse1020', 'logout'),
(92, 33, 0, '09:23:36', '2024-02-10', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'login'),
(93, 33, 0, '22:57:19', '2024-02-12', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'login'),
(94, 33, 0, '22:57:41', '2024-02-12', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'logout'),
(95, 33, 0, '23:24:06', '2024-02-12', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'login'),
(96, 33, 0, '23:24:15', '2024-02-12', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'login'),
(97, 33, 0, '23:24:21', '2024-02-12', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'logout'),
(98, 33, 0, '23:24:36', '2024-02-12', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'login'),
(99, 33, 0, '23:24:39', '2024-02-12', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'logout'),
(100, 33, 0, '23:24:41', '2024-02-12', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'login'),
(101, 33, 0, '23:24:43', '2024-02-12', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'logout'),
(102, 33, 0, '22:11:31', '2024-02-13', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'login'),
(103, 33, 0, '22:12:53', '2024-02-13', 'Nimshi Shehanida Silva', 'itcs', 'kuhdse22.1f-050', 'logout'),
(104, 30, 0, '22:53:52', '2024-02-25', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(105, 30, 0, '23:01:51', '2024-02-25', 'Saman', 'itcs', 'kuhdse1020', 'logout'),
(106, 30, 0, '23:02:04', '2024-02-25', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(107, 30, 0, '19:22:48', '2024-02-26', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(108, 30, 0, '20:57:45', '2024-02-26', 'Saman', 'itcs', 'kuhdse1020', 'logout'),
(109, 30, 0, '22:14:27', '2024-02-26', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(110, 30, 0, '20:48:40', '2024-03-05', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(111, 30, 0, '21:51:09', '2024-03-05', 'Saman', 'itcs', 'kuhdse1020', 'logout'),
(112, 35, 0, '21:52:20', '2024-03-05', 'Mahinda Rajapaksha', 'itcs', 'kuhdse22.1f-025', 'login'),
(113, 35, 0, '21:54:56', '2024-03-05', 'Mahinda Rajapaksha', 'itcs', 'kuhdse22.1f-025', 'logout'),
(114, 36, 0, '21:59:30', '2024-03-05', 'test11', 'hr', 'kuhdse22.1f-070', 'login'),
(115, 36, 0, '21:59:50', '2024-03-05', 'test11', 'hr', 'kuhdse22.1f-070', 'logout'),
(116, 36, 0, '21:59:59', '2024-03-05', 'test11', 'hr', 'kuhdse22.1f-070', 'login'),
(117, 35, 0, '10:34:07', '2024-03-08', 'Mahinda Rajapaksha', 'itcs', 'kuhdse22.1f-025', 'login'),
(118, 35, 0, '10:40:19', '2024-03-08', 'Mahinda Rajapaksha', 'itcs', 'kuhdse22.1f-025', 'logout'),
(119, 37, 0, '10:50:58', '2024-03-08', 'Nimshi Silva12', 'itcs', 'kuhdse22.1f-0755', 'login'),
(120, 37, 0, '10:57:30', '2024-03-08', 'Nimshi Silva12', 'itcs', 'kuhdse22.1f-0755', 'logout'),
(121, 38, 0, '11:23:27', '2024-03-08', 'test student', 'itcs', 'kuhdse22.1f-0566', 'login'),
(122, 38, 0, '11:27:31', '2024-03-08', 'test student', 'itcs', 'kuhdse22.1f-0566', 'logout'),
(123, 30, 0, '11:28:07', '2024-03-08', 'Saman', 'itcs', 'kuhdse1020', 'login'),
(124, 30, 0, '11:31:27', '2024-03-08', 'Saman', 'itcs', 'kuhdse1020', 'logout'),
(125, 38, 0, '11:31:42', '2024-03-08', 'test student', 'itcs', 'kuhdse22.1f-0566', 'login'),
(126, 38, 0, '11:34:12', '2024-03-08', 'test student', 'itcs', 'kuhdse22.1f-0566', 'logout'),
(127, 38, 0, '10:09:09', '2024-03-09', 'test student', 'itcs', 'kuhdse22.1f-0566', 'login');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `pid` int(11) NOT NULL,
  `postdate` date NOT NULL,
  `img` varchar(255) NOT NULL,
  `sid` int(11) NOT NULL,
  `time` time NOT NULL,
  `status` varchar(50) NOT NULL,
  `isDelete` varchar(10) NOT NULL,
  `course` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `postData` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`pid`, `postdate`, `img`, `sid`, `time`, `status`, `isDelete`, `course`, `name`, `image`, `title`, `postData`) VALUES
(27, '2024-01-28', '', 30, '12:58:11', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'asdas', 'asdasd'),
(28, '2024-01-28', '', 30, '16:21:23', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'UI/UX', 'how to explain the difference between UI and UX with examples'),
(29, '2024-01-28', 'cover.jpg', 30, '16:22:55', '1', '0', 'itcs', 'Saman', 'cove.jpg', 'Test problem', 'Hello Nimshi I have a problem'),
(30, '2024-01-29', '', 30, '21:30:54', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'What is your name', 'Saman kumara'),
(31, '2024-01-29', '', 30, '21:35:57', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'What is UI/UX', 'Why we need ui/ux'),
(32, '2024-01-29', 'sendEmailsPHP2024.jpg', 30, '21:42:02', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'Who are you', 'Why why why'),
(33, '2024-01-29', '', 30, '21:44:48', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'Inventory Management System', 'You are tasked with developing an Inventory Management System for a retail business. The system should allow the business to keep track of its products, manage stock levels, and generate reports. The key features required for the system include:\r\n\r\nProduct Management:\r\n\r\nAdd new products with details such as name, description, and price.\r\nUpdate product information.\r\nDelete products that are no longer in stock.\r\nStock Management:\r\n\r\nTrack the quantity of each product in stock.\r\nReceive new stock and update the inventory accordingly.\r\nRecord sales and reduce stock levels.\r\nReporting:\r\n\r\nGenerate reports on current stock levels.\r\nProvide sales reports for a specified time period.\r\nDisplay alerts for products running low on stock.\r\nUser Authentication:\r\n\r\nImplement user authentication to control access to the system.\r\nDefine different user roles (e.g., admin, staff) with appropriate permissions.\r\nUser Interface:\r\n\r\nDesign a user-friendly interface for easy navigation.\r\nEnsure a responsive design for access on various devices.'),
(34, '2024-01-29', 'pngegg (7).png', 30, '21:45:54', 'rejected', '0', 'itcs', 'Saman', 'cove.jpg', 'Here are some emojis that you can use:', '😀 - Grinning Face\r\n😍 - Heart Eyes\r\n🌟 - Star\r\n🎉 - Party Popper\r\n🌈 - Rainbow\r\n🍕 - Pizza\r\n🚀 - Rocket\r\n📚 - Books\r\n💡 - Light Bulb\r\n🎸 - Guitar\r\n🌺 - Hibiscus\r\n🐱 - Cat Face\r\n🐾 - Paw Prints'),
(35, '2024-01-29', 'images (1).png', 30, '21:50:59', 'rejected', 'true', 'itcs', 'Saman', 'cove.jpg', 'Authorization by Laravel cookies', 'My application uses Laravel/Fortify package, guarded by web/session/memcached. I want to add golang-powered websocket server in my app. And I need to authorize users. As I understand I can use cookies saved by Laravel. This is decrypted cookies (I think I can decrypt it in golang module with env:APP_KEY)\r\n\r\n  \"cookies\": {\r\n    \"parameters\": {\r\n      \"XSRF-TOKEN\": \"<xsrf_token>\",\r\n      \"<app_name>_session\": \"<session>\"\r\n    }\r\n  }\r\nThis is record from memcached:\r\n\r\n    \"key\" => \"<cache_prefix>:<session>\"\r\n    \"value\" => \"a:5:{\r\n        s:6:\"_token\";s:40:\"<xsrf_token>\";\r\n        s:6:\"_flash\";a:2:{s:3:\"old\";a:0:{}s:3:\"new\";a:0:{}}\r\n        s:9:\"_previous\";a:1:{s:3:\"url\";s:16:\"http://localhost\";}\r\n        s:3:\"url\";a:0:{}\r\n        s:50:\"login_web_[0-9a-f]\";i:<user_id>;\r\n    }\"\r\nSo, in golang I decrypt cookies, read from memcached session record, check xsrf_token and I have <user_id> by key login_web_<[0-9a-f]+>? What mean hex numbers after \'login_web_\'? Do I need to check it to use authorization correctly and safely?\r\n\r\nThanks.'),
(36, '2024-01-30', '', 30, '20:06:31', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'Why we are develop this?', 'What is the reason of dev'),
(37, '2024-01-30', 'pngwing.com (4).png', 30, '21:01:58', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'asddasdas', 'asdasdasddsa'),
(38, '2024-01-30', 'pngwing.com (4).png', 30, '21:01:58', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'asddasdas', 'asdasdasddsa'),
(39, '2024-01-30', 'pngwing.com (4).png', 30, '21:01:58', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'asddasdas', 'asdasdasddsa'),
(40, '2024-01-30', 'pngegg (4).png', 30, '21:01:58', 'rejected', 'true', 'itcs', 'Saman', 'cove.jpg', 'asdasd', 'asdasdasd'),
(41, '2024-01-30', 'pngegg (4).png', 30, '21:01:58', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'asdasd', 'asdasdasd'),
(42, '2024-01-30', 'pngegg (4).png', 30, '21:01:58', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'asdasd', 'asdasdasd'),
(43, '2024-01-30', 'pngegg (4).png', 30, '21:01:58', 'rejected', 'true', 'itcs', 'Saman', 'cove.jpg', 'asdasd', 'asdasdasd'),
(44, '2024-01-30', 'pngegg (4).png', 30, '21:01:58', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'asdasd', 'asdasdasd'),
(45, '2024-01-30', 'Impactful-teaching-strategies.webp', 30, '21:03:10', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'Test problem', 'Why all????'),
(46, '2024-01-30', 'Screenshot (26).png', 30, '21:06:48', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'Help me to solve this machine learning problem', 'Help me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problemHelp me to solve this machine learning problem'),
(47, '2024-02-02', 'v.jpeg', 31, '19:21:20', 'accepted', '0', 'hr', 'Saman Kumara Nimal', '', 'This is my first problem', 'I have no problem with anything.'),
(48, '2024-02-02', '20828ae.webp', 31, '19:32:19', 'accepted', '0', 'hr', 'Saman Kumara Nimal', '', 'This is my second problem', 'This is my second problemThis is my second problemThis is my second problemThis is my second problemThis is my second problemThis is my second problemThis is my second problemThis is my second problemThis is my second problem'),
(49, '2024-02-02', 'images.jpg', 30, '21:08:23', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'test problem', 'this is a test problem'),
(50, '2024-02-03', 'pngegg (1).png', 32, '11:09:49', 'accepted', '0', 'itcs', 'Nimshi Silva', '', 'This is my second problem', 'This is my second problem This is my second problem This is my second problem This is my second problem This is my second problem This is my second problem'),
(51, '2024-02-03', '', 32, '12:39:28', 'accepted', '0', 'itcs', 'Nimshi Silva', '', 'asdasdasd', 'asdasdasdasdasd'),
(52, '2024-02-03', 'cw.png', 31, '13:05:40', 'accepted', '0', 'hr', 'Saman Kumara Nimal', '', 'This is a HR post', 'This is a HR postThis is a HR postThis is a HR postThis is a HR postThis is a HR postThis is a HR postThis is a HR postThis is a HR post'),
(53, '2024-02-04', 'Screenshot (50).png', 33, '14:51:34', 'rejected', 'true', 'itcs', 'Nimshi Shehanida Silva', '', 'This is my first post', 'This is my first postThis is my first postThis is my first postThis is my first postThis is my first postThis is my first postThis is my first postThis is my first postThis is my first post'),
(54, '2024-02-04', '', 32, '15:00:34', 'accepted', '0', 'itcs', 'Nimshi Silva', '', 'sfasfasf', 'asfasfasf'),
(55, '2024-02-10', 'Screenshot (32).png', 33, '09:24:28', 'rejected', '0', 'itcs', 'Nimshi Shehanida Silva', '', 'askdasdasdasd', 'sadasdasddddddddddddddddddddddd'),
(56, '2024-02-25', '', 30, '22:54:12', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'hello this is testinggg', 'hello this is testinggghello this is testinggghello this is testinggghello this is testinggghello this is testinggg'),
(57, '2024-02-25', '', 30, '23:01:21', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'hello test2 test2', 'hello test2 test2hello test2 test2hello test2 test2hello test2 test2hello test2 test2hello test2 test2'),
(58, '2024-02-25', '', 30, '23:01:36', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'hello test2 test2', 'hello test2 test2hello test2 test2hello test2 test2hello test2 test2hello test2 test2hello test2 test2'),
(59, '2024-02-25', '', 30, '23:02:23', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'hello test2 test2hello test2 test2', 'hello test2 test2hello test2 test2'),
(60, '2024-02-25', '', 30, '23:18:10', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'test3', 'test3'),
(61, '2024-02-25', '', 30, '23:26:47', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'adsfasdf', 'afdsafafafd'),
(62, '2024-02-25', '', 30, '23:34:37', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'asdasdffffff', 'fffff'),
(63, '2024-02-25', '', 30, '23:35:47', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'hhhhh', 'hhjj'),
(64, '2024-02-25', '', 30, '23:38:36', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', '23123213123', '324234324324'),
(65, '2024-02-25', '', 30, '23:39:18', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'sadasdasdasdasdasd', 'asdasdasdasdasdasdasd'),
(66, '2024-02-26', '', 30, '00:23:58', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'test test testttt', 'test test testttttest test testttttest test testttttest test testttt'),
(67, '2024-02-26', '', 30, '00:27:05', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'me me me me', 'me me me meme me me meme me me meme me me meme me me meme me me meme me me me'),
(68, '2024-02-26', '', 30, '19:23:33', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'eps topiks', 'eps topikseps topikseps topikseps topikseps topikseps topiks'),
(69, '2024-02-26', 'Screenshot (28).png', 30, '19:28:05', 'rejected', '0', 'itcs', 'Saman', 'cove.jpg', 'tttttttttesttttttttttet', 'tttttttttesttttttttttettttttttttesttttttttttettttttttttesttttttttttettttttttttesttttttttttettttttttttesttttttttttettttttttttesttttttttttettttttttttesttttttttttettttttttttesttttttttttettttttttttesttttttttttettttttttttesttttttttttettttttttttesttttttttttet'),
(70, '2024-02-26', '', 30, '19:28:58', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'tttttttttesttttttttttet', 'tttttttttesttttttttttettttttttttesttttttttttet'),
(71, '2024-02-26', 'Screenshot 2024-01-18 142738.png', 30, '19:30:17', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'asdasdffg', 'fff'),
(72, '2024-02-26', '', 30, '19:44:43', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'sadasdasd', 'asdasdasd'),
(73, '2024-02-26', '', 30, '22:15:18', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'Testing', 'Testing'),
(74, '2024-02-26', '', 30, '22:16:13', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'test11', 'test11test11test11'),
(75, '2024-03-05', '', 30, '20:48:54', 'accepted', '0', 'itcs', 'Saman', 'cove.jpg', 'testinggg', 'testinggg'),
(76, '2024-03-05', '', 35, '21:52:42', 'accepted', '0', 'itcs', 'Mahinda Rajapaksha', '', 'Mahinda mahaththaya', 'Mahinda mahaththaya'),
(77, '2024-03-05', '', 36, '22:00:29', 'accepted', '0', 'hr', 'test11', '', 'hr test', 'hr test'),
(78, '2024-03-08', '', 35, '10:35:33', 'accepted', '0', 'itcs', 'Mahinda Rajapaksha', '', 'dfgdfgdfgd', 'dfgdfgdfgdfg'),
(79, '2024-03-08', '', 37, '10:51:06', 'accepted', '0', 'itcs', 'Nimshi Silva12', '', 'test', 'ting'),
(80, '2024-03-08', 'Screenshot (50).png', 38, '11:24:14', 'accepted', '0', 'itcs', 'test student', '', 'Test post', 'Test post problem');

-- --------------------------------------------------------

--
-- Table structure for table `savedcomment`
--

CREATE TABLE `savedcomment` (
  `cid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `pid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `savedcomment`
--

INSERT INTO `savedcomment` (`cid`, `sid`, `pid`) VALUES
(16, 33, 45),
(17, 33, 44),
(18, 33, 36),
(19, 33, 34),
(20, 33, 33),
(21, 33, 46),
(22, 33, 50),
(23, 33, 51),
(24, 33, 49),
(25, 33, 46),
(26, 33, 46),
(27, 33, 51),
(28, 33, 32),
(29, 33, 32),
(30, 33, 33),
(31, 33, 29),
(32, 30, 50),
(33, 30, 50),
(34, 30, 50),
(35, 30, 51),
(36, 35, 63),
(37, 35, 58),
(38, 35, 50),
(39, 36, 47),
(40, 35, 75),
(41, 38, 79),
(42, 38, 68),
(43, 30, 80);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `sid` int(11) NOT NULL,
  `student_name` varchar(255) NOT NULL,
  `index_no` varchar(255) NOT NULL,
  `course` varchar(255) NOT NULL,
  `s_password` varchar(255) NOT NULL,
  `cphoto` varchar(255) DEFAULT NULL,
  `pimage` varchar(255) DEFAULT NULL,
  `added_date` date NOT NULL,
  `updated_date` date NOT NULL,
  `added_time` time NOT NULL,
  `updated_time` time NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`sid`, `student_name`, `index_no`, `course`, `s_password`, `cphoto`, `pimage`, `added_date`, `updated_date`, `added_time`, `updated_time`, `email`) VALUES
(25, 'Nimal Kumara', 'kuans22.1f-15', 'env_science', '$2y$10$vv40Ly7.DjjlpX4DiVvNeesrc1x2CCRG/VADHZiP9wZMe4uBDy31O', NULL, NULL, '2024-01-20', '2024-01-22', '20:06:22', '06:12:00', 'nimshisilva7@gmail.com'),
(26, 'Cameron Green', 'kuhdse22.1f-015', 'hr', '$2y$10$/vs8pj5PA6y53wPYaXzlQe8uDjiPCeDZ8TPy1DzTgxkt7LSNbclyC', NULL, NULL, '2024-01-20', '2024-01-22', '20:07:25', '06:11:24', 'sasindulakshithabandara@gmail.com'),
(27, 'Adman Sampa', 'kuhdse22.1f-012', 'itcs', '$2y$10$M5vT2J00fId3cJWLAzDuqujnskXhI7Oz8gB8VkKI0GtpaC3wb11Nq', NULL, NULL, '2024-01-20', '2024-01-22', '20:47:00', '06:10:50', 'gpunsisi14@gmail.com'),
(28, 'Ishan Shanuka', 'kuhdse22.1f-023', 'hr', '$2y$10$CELENACwYVR8kRZc4DPJPOwbQ1zhQt9zVHDS0WfvBHRNYqhHWLrIq', NULL, NULL, '2024-01-22', '2024-01-22', '10:53:09', '10:53:09', ''),
(29, 'testingStu', 'kuhdse22.1f-018', 'hr', '$2y$10$kiLX4bgdFTOGyjDHzRbnaOheNnY/UQxotxXcEVzxhPKJVBJzjVsky', NULL, NULL, '2024-01-25', '2024-01-26', '06:20:06', '19:47:34', ''),
(30, 'Saman', 'kuhdse1020', 'itcs', '$2y$10$Z.0xfSN.rWvsMnAzJqigTuimkEzNJD.n.Fl2vglgJRaSM4wYCbpUm', NULL, 'cove.jpg', '2024-01-26', '2024-01-26', '15:18:37', '15:18:37', 'sasindulakshithabandara@gmail.com'),
(31, 'Saman Kumara Nimal', 'kuhdhr22.1f-025', 'hr', '$2y$10$RoB/Teq181xxz0QuPn17OuEOGRctPmX9Y1INZa5gIBJS47DP/qfEm', NULL, NULL, '2024-02-02', '2024-02-02', '19:14:09', '19:14:09', ''),
(32, 'Nimshi Silva', 'kudcsd22.1f-012', 'itcs', '$2y$10$SQpnUGZiJuSYBUIwom0LeOhorKNTYy50mGH3cCm9o3VXcwBBuXqqe', NULL, NULL, '2024-02-03', '2024-02-03', '08:26:30', '08:26:30', 'KUHDSE221F-023@student.nibm.lk'),
(33, 'Nimshi Shehanida Silva', 'kuhdse22.1f-050', 'itcs', '$2y$10$2MB0G.mjJajs8mY4CIZ6AOTu93Wd/.mmY842FVpmCoF4oeNNcS0gO', NULL, NULL, '2024-02-03', '2024-02-03', '19:55:13', '19:55:13', 'nimshisilva7@gmail.com'),
(34, 'testing Student', 'kuhdse22.1f-060', 'itcs', '$2y$10$nsxqvjZ.N/OQNvV4BDHBX.y5NfL2yCchLkCrLb4hoEVBgA38eYjYG', NULL, NULL, '2024-02-21', '2024-02-21', '19:56:28', '19:56:28', 'sasindu.bandara@innovative-e.com'),
(35, 'Grren Wero', 'kuhdse22.1f-025', 'itcs', '$2y$10$VinDHrkRUIF1Ip443hUWO.LrswZWbpk9OvxYVEPnYsS56Y.afBqKe', NULL, NULL, '2024-02-25', '2024-03-05', '20:51:07', '21:52:05', 'KUHDSE221F-018@student.nibm.lk'),
(36, 'test11', 'kuhdse22.1f-070', 'hr', '$2y$10$XSlfxFZdoSXcg577ZQvUDeVNa0MZsWJ1iIlvOVeL7R5XGGfP2KouW', NULL, NULL, '2024-03-05', '2024-03-05', '21:54:49', '21:54:49', 'nimshisilva7@gmail.com'),
(37, 'Nimshi Silva12', 'kuhdse22.1f-0755', 'itcs', '$2y$10$HGPWhN6sh.K5L9dEHG42huiI1Qos8Q4H9pyIvLIfNfpD4pWp1LCpi', NULL, NULL, '2024-03-08', '2024-03-08', '10:40:06', '10:40:06', 'sasindulakshithabandara@gmail.com'),
(38, 'test student', 'kuhdse22.1f-0566', 'itcs', '$2y$10$ojp6x1RkSbk6/8WtUk3My.oulyyvq1C5DQXw4MOSDBL3x42LmvKkW', NULL, NULL, '2024-03-08', '2024-07-25', '11:19:14', '20:09:35', 'sasindulakshithabandara@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `ForeignKey` (`lec_id`),
  ADD KEY `stu_id` (`stu_id`),
  ADD KEY `test` (`pid`);

--
-- Indexes for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`logId`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `savedcomment`
--
ALTER TABLE `savedcomment`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `foreignKey` (`pid`),
  ADD KEY `foreignKey1` (`sid`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `lecturer`
--
ALTER TABLE `lecturer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `logId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `savedcomment`
--
ALTER TABLE `savedcomment`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `test` FOREIGN KEY (`pid`) REFERENCES `post` (`pid`);

--
-- Constraints for table `savedcomment`
--
ALTER TABLE `savedcomment`
  ADD CONSTRAINT `foreignKey1` FOREIGN KEY (`sid`) REFERENCES `student` (`sid`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
